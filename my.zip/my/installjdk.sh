#!/bin/bash
yes | yum install jdk
