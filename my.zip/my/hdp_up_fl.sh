#!/bin/bash
c=`cat /root/Desktop/my/file_location.txt`
`hadoop fs -put $c`

