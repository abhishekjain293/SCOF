#!/bin/bash
for ip in $(cat /root/Desktop/my/connected_ip.txt)
do
echo $ip
done

