#!/bin/bash
ip5=`cat /root/Desktop/my/systemip.txt`
ipp=`cat /root/Desktop/my/location.txt`
ip2=`cat /root/Desktop/my/namenodeip.txt`
for ip4 in `cat /root/Desktop/my/systemip.txt`
do
if [ "$ip2" = "$ip4" ]
then
`sh /root/Desktop/my/jobrun1.sh`
else
`sshpass -p 293293 ssh $ip2 mkdir /root/Desktop/my`
`sshpass -p 293293 ssh $ip2 mount -t nfs $ip5:/root/Desktop/my /root/Desktop/my`
`sshpass -p 293293 ssh $ip2 sh /root/Desktop/my/jobrun1.sh`
`sshpass -p 293293 ssh $ip2 umount /root/Desktop/my`
fi
done 			
