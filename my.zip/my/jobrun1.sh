#!/bin/bash
job=`cat /root/Desktop/my/word.txt`
`hadoop jar /usr/share/hadoop/hadoop-examples-1.2.1.jar wordcount $job /output2`
