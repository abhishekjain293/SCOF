#!/bin/bash
hadoop-daemon.sh stop tasktracker
hadoop-daemon.sh stop datanode
