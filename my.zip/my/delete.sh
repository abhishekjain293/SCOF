#!/bin/bash
`sudo rm -rf /name1`
`sudo rm -rf /name2`
