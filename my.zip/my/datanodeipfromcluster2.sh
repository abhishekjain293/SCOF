#!/bin/bash
ip2=`cat /root/Desktop/my/namenodeip.txt`
for ip in `cat /root/Desktop/my/connected_ip.txt`
do
((count1++));
if [[ "$ip2" = "$ip"  ]]
then 
`echo $ip > /root/Desktop/my/namenodeip.txt`
else
`echo $ip >> /root/Desktop/my/datanodeip.txt`
fi
done 
