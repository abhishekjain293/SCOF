#!/bin/bash

yes | cp  -f /var/www/html/data.txt /root/Desktop/my/namenodeip.txt
