#!/bin/bash

ifconfig > systeminfo.txt
grep "inet addr:192" systeminfo.txt | cut -d ":" -f2 | awk '{print $1}' > systemip.txt
