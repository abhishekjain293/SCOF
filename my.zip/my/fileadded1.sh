#!/bin/bash
file1=`cat /root/Desktop/my/location.txt`
`hadoop fs -put $file1 /`
