#!/bin/bash
yes | yum install hadoop
