mv /root/Desktop/my/username.txt /etc/hadoop 
