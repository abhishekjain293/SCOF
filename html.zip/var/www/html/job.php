<!DOCTYPE html>
<html>
	<head>
		<title>
			SCOF Terminal
		</title>
		

	</head>
	<body>
		<h1><center><font color="blue">SCOF - The SUPER MACHINE</font></center></h1>
		<center>
			  
			</br></br>
			<h1><font color="white">Enter the Location Of file</font></h1>
			</br></br></br>
			<form action="locationjob.php" method="post">
			<label for="name1">Enter The Location Of File on HDFS</label>
			<input class="form1" type="text" name="name"><br><br><br>
			<input class="form2" type="submit" onclick="window.location.href='locationjob.php'">
			</form>
			</br><br></br></br>
		</center>
		<style type="text/css">
			body
			{
				background-image: url(background.jpg);
				-webkit-background-size: cover;
				-moz-background-size: cover;
				-o-background-size: cover;
				background-size: cover;
			}
			.form1
			{
				margin-right:100px;
				background-image: url(backbox.jpg);
				color: green;
				border-radius: 19px;
				font-weight: bold;
				background-size : cover;
				background-repeat: no-repeat;
				background-position: center;
			}
			.form2
			{
				margin-right:50px;
				background-image: url(backbox.jpg);
				color: green;
				border-radius: 60px;
				font-weight: bold;
				background-size : cover;
				background-repeat: no-repeat;
				background-position: center;
			}
			label 
			{
   				 cursor: default;
				 color:white;
			}
			.scrii
			{
				color=white;
			}
			
		</style>
		
	</body>
</html>
