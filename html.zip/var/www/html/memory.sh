 grep "Mem" f.txt | awk '{print $4}'> m1.txt
