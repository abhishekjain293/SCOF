<!DOCTYPE html>
<html>
	<head>
		<title>
			SCOF Terminal
		</title>
	</head>
	<body>
		<h1><center><font color="blue">SCOF - The SUPER MACHINE</font></center></h1>
		<center>
			</br></br></br>
			<h1><font color="white">Are You a..?</font></h1>			
			</br></br>
			<button class="butt" type="button" onclick="window.location.href='login1.php'"><h3>CLIENT</h3></button>
			</br></br>
			<h2><font color="white">OR</font></h2>
			</br></br>
			<button class="butt" type="button" onclick="window.location.href='login.php'"><h3>ADMINISTRATOR</h3></button>
		</center>
		<style type="text/css">
			body
			{
				background-image: url(background.jpg);
				-webkit-background-size: cover;
				-moz-background-size: cover;
				-o-background-size: cover;
				background-size: cover;
			}
			.butt
			{
				background-image: url(backbox.jpg);
				color: green;
				border-radius: 19px;
				font-weight: bold;
				background-size : cover;
				background-repeat: no-repeat;
				background-position: center;
			}
		</style>
	</body>
</html>
