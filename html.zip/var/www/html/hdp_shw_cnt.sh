#!/bin/bash
c=`cat /root/Desktop/my/file_locatio1.txt`
`hadoop fs -ls $c`

