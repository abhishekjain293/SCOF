#!/bin/bash
hadoop-daemon.sh stop jobtracker
hadoop-daemon.sh stop namenode
