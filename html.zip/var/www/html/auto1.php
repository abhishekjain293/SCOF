<!DOCTYPE html>
<html>
	<head>
		<title>
			SCOF Terminal
		</title>
	</head>
	<body>
		<h1><center><font color="blue">SCOF - The SUPER MACHINE</font></center></h1>
			</br>
			<center>
			<h1><font color="white">What Do You Want to Do Now?</font></h1>
			</br></br>
			<button class="but1" type="button" onclick="window.location.href='add.php'"><h3>ADD FILE ON CLUSTER</h3></button>
			</br></br>
			</center>
			<button class="but2" type="button" onclick="window.location.href='job.php'"><h3>RUN JOB</h3></button>
			<button class="but3" type="button" onclick="window.location.href='choicehome.php'"><h3>ADD USER</h3></button>
			</br></br>
			<button class="but4" type="button" onclick="window.location.href='choicehome.php'"><h3>SHOW CONTENTS</h3></button>
			<button class="but5" type="button" onclick="window.location.href='choicehome.php'"><h3>CHECKPOINTING</h3></button>
			</br></br>
			<button class="but6" type="button" onclick="window.location.href='choicehome.php'"><h3>CHE NUMBER</h3></button>
			<button class="but7" type="button" onclick="window.location.href='choicehome.php'"><h3>saat number</h3></button>
			</br>
		<style type="text/css">
			body
			{
				background-image: url(background.jpg);
				-webkit-background-size: cover;
				-moz-background-size: cover;
				-o-background-size: cover;
				background-size: cover;
			}
			.but1
			{
				background-image: url(backbox.jpg);
				color: green;
				border-radius: 19px;
				font-weight: bold;
				background-size : cover;
				background-repeat: no-repeat;
				background-position: center;
			}
			.but2
			{
				background-image: url(backbox.jpg);
				color: green;
				border-radius: 19px;
				font-weight: bold;
				background-size : cover;
				background-repeat: no-repeat;
				background-position: center;
				margin-left: 450px;
			}
			.but3
			{
				background-image: url(backbox.jpg);
				color: green;
				border-radius: 19px;
				font-weight: bold;
				background-size : cover;
				background-repeat: no-repeat;
				background-position: center;
				float: right;
				margin-right: 450px;
			}
			.but4
			{
				background-image: url(backbox.jpg);
				color: green;
				border-radius: 19px;
				font-weight: bold;
				background-size : cover;
				background-repeat: no-repeat;
				background-position: center;
				margin-left: 275px;
			}
			.but5
			{
				background-image: url(backbox.jpg);
				color: green;
				border-radius: 19px;
				font-weight: bold;
				background-size : cover;
				background-repeat: no-repeat;
				background-position: center;
				margin-right: 275px;
				float: right;
			}
			.but6
			{
				background-image: url(backbox.jpg);
				color: green;
				border-radius: 19px;
				font-weight: bold;
				background-size : cover;
				background-repeat: no-repeat;
				background-position: center;
				margin-left: 100px;
			}
			.but7
			{
				background-image: url(backbox.jpg);
				color: green;
				border-radius: 19px;
				font-weight: bold;
				background-size : cover;
				background-repeat: no-repeat;
				background-position: center;
				margin-right: 100px;
				float:right;
			}
		</style>
	</body>
</html>
